<?php

namespace kushki\lib;

class KushkiCurrency {
const
__default = 'USD',
USD = 'USD',
COP = 'COP';
}
