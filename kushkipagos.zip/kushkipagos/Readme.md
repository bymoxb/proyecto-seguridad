# kushkipagos

##Acerca de

Permite a los compradores pagar con tarjeta mediante kushki

##Instalación

Para instalar el módulo se debe seguir los siguientes pasos:

1. Descargamos el paquede del módulo en zip.
2. Desde el panel de control de nuestra tienda **Prestashop**, iremos a la sección de **Módulos** y a continuación seleccionaremos el botón ```Subir un módulo```.
3. Arrastraremos el zip del módulo descargado hacia la pantalla en nuestro panel de control de la tienda.

##Configuración

Se debe configurar los siguientes parametros antes de utilizar el módulo:

* **Public key** y **Private key** .
* **Entorno de prueba**: Definimos si nuestro módulo esta en fase de pruebas o en producción.
* **Permitir transferencia**: Válido solo para colombia, definimos si vamos a permitir pagos con **PSE**
* **Razon Social**: Válido solo para colombia, definimos la razón social para transferencias con **PSE**



**NOTA:** El módulo no podrá ser utilizado si antes no se ha configurado las llaves publicas y privadas subministradas por **Kushki** 